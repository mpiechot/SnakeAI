package Brains;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import Logic.Field;
import Logic.Field.CellType;
import Logic.GameInfo;
import Logic.Point;
import Logic.Snake;
import Logic.Snake.Direction;
import Logic.SnakeBrain;

//SurvivalAI
//Created by: Julia Hofmann, Marco Piechotta

public class SurvivalAI implements SnakeBrain {
	private HashMap<Point, Integer> apples = new HashMap<>();
	private Node start;
	private Node target;
	
	//A* 
	private int[][] moveableMap;
	private int[][] heuristik;
	private List<Node> openList = new LinkedList<>();
	private List<Node> closedList = new LinkedList<>();

	@Override
	public Direction nextDirection(GameInfo gameInfo, Snake snake) {
		// TODO Auto-generated method stub
		Direction move = null;
//		Snake targetSnake = null;
		start = new Node(snake.headPosition(),snake.headPosition(),0,0);
		getApples(gameInfo.field(), start.getFrom());
		for(Snake s : gameInfo.snakes())
		{
			if(!s.equals(snake))
			{
				Point temp = s.segments().get(0);
//				targetSnake = s;
				target = new Node(temp,temp,0,0);
				break;
			}
		}
		do {		
				//-----CODE TO IMPROVE!----
			//Steht das Ziel vor einem Apfel?`
//			Point head = targetSnake.headPosition();
//			if(isAppleNear(gameInfo.field(), head))
//			{
//				if(snake.headPosition().x < gameInfo.field().width()/2)
//				{
//					if(isMoveValid(Direction.RIGHT, snake, gameInfo))
//						return Direction.RIGHT;
//					else
//					{
//						if(snake.headPosition().y < gameInfo.field().height()/2)
//						{
//							return Direction.DOWN;
//						}
//						else
//							return Direction.UP;
//					}
//				}
//				else
//				{
//					if(isMoveValid(Direction.LEFT, snake, gameInfo))
//						return Direction.LEFT;
//					else
//					{
//						if(snake.headPosition().y < gameInfo.field().height()/2)
//							return Direction.DOWN;
//						else
//							return Direction.UP;
//					}
//				}
//			}
			//Ist das Ziel direkt erreichbar, weiche aus!
			if (Math.abs(target.getTo().x - start.getTo().x) == 1 && target.getTo().y == start.getTo().y)
				if(isValidMovePossible(snake, gameInfo))
				{
					for(Direction dir : Direction.values())
						if(isMoveValid(dir, snake, gameInfo))
							return dir;
				}
				else
					return getDirection(start.getTo(), target.getTo());
			if (Math.abs(target.getTo().y - start.getTo().y) == 1 && target.getTo().x == start.getTo().x)
				if(isValidMovePossible(snake, gameInfo))
				{
					for(Direction dir : Direction.values())
						if(isMoveValid(dir, snake, gameInfo))
							return dir;
				}
				else
					return getDirection(start.getTo(), target.getTo());
			
			calculateMoveMap(gameInfo.field());
			//Ist das Ziel nicht durch 1 Schritt erreichbar, suche den Weg dort hin
			move = getPath();
		} while (move == null);
		return move;
	}
//	private boolean isAppleNear(Field f, Point head)
//	{
//		return f.getApple(new Point(head.x+1,head.y))!= null || f.getApple(new Point(head.x-1,head.y))!= null || f.getApple(new Point(head.x,head.y+1))!= null || f.getApple(new Point(head.x,head.y-1))!= null;
//	}
	private void getApples(Field f, Point snakeHead) {
		apples.clear();
		for (int i = 0; i < f.width(); i++)
			for (int j = 0; j < f.height(); j++)
				if (f.getApple(new Point(i, j)) != null) {
					int dist = Math.abs(snakeHead.x - i + snakeHead.y - j);
					apples.put(new Point(i, j), dist);
				}
	}

	private void calculateMoveMap(Field f) {
		moveableMap = new int[f.width() + 1][f.height() + 1];
		heuristik = new int[f.width() + 1][f.height() + 1];
		for (int i = 0; i < f.width(); i++) {
			for (int j = 0; j < f.height(); j++) {
				heuristik[i][j] = getDistance(new Point(i,j),target.getTo());
				if (f.cell(new Point(i, j)).equals(CellType.APPLE))
					moveableMap[i][j] = 1;
				if (f.cell(new Point(i, j)).equals(CellType.WALL))
					moveableMap[i][j] = 99;
				if (f.cell(new Point(i, j)).equals(CellType.SPACE))
					moveableMap[i][j] = 1;
				if (f.cell(new Point(i, j)).equals(CellType.SNAKE)) {
					moveableMap[i][j] = 99;
				}
			}
		}
	}

	private Direction getPath() {
		openList.clear();
		closedList.clear();
		
		// Calculate A*
		openList.add(start);
		while (!isInClosedList(target) && !openList.isEmpty()) {
			Node min = getMin();
			openList.remove(min);
			closedList.add(min);
			Point current = min.getTo();
			for (int i = -1; i <= 1; i += 2) {
				if (current.x + i < 30 && current.x + i >= 0)
					updateOpenList(new Point(current.x + i, current.y), min);
				if (current.y + i < 20 && current.y + i >= 0)
					updateOpenList(new Point(current.x, current.y + i), min);
			}
		}
		Node field = getMovePair(target.getTo());
		if (field == null) {
			return null;
		}
		closedList.remove(0);
		while (!field.getFrom().equals(start.getFrom())) {
			field = getMovePair(field.getFrom());
		}
		return getDirection(field.getFrom(), field.getTo());
	}

	private void updateOpenList(Point check, Node node) {
		Node checkNode = new Node(node,check,heuristik[check.x][check.y],moveableMap[check.x][check.y]);
		if (!isInClosedList(checkNode))
			if (isInOpenList(checkNode)) {
				Node duplicate = getElement(checkNode);
				if (checkNode.getGCosts() < duplicate.getGCosts()) {
					openList.remove(duplicate);
					openList.add(checkNode);
				}
			} else
				openList.add(checkNode);
	}
	private boolean isInClosedList(Node n) {
		for (Node closed : closedList)
		{
			if (closed.getTo().equals(n.getTo()))
				return true;
		}
		return false;
	}

	private Node getMovePair(Point p) {
		for (Node n : closedList)
			if (n.getTo().equals(p))
				return n;

		return null;
	}

	private boolean isInOpenList(Node n) {
		for (Node open : openList)
		{
			if (open.getTo().equals(n.getTo()))
				return true;
		}
		return false;
	}

	private Node getElement(Node n) {
		for (Node open : openList)
		{
			if (open.getTo().equals(n.getTo()))
				return open;
		}
		return null;
	}

	private Node getMin() {
		int minCost = Integer.MAX_VALUE;
		Node min = null;
		for (Node node : openList)
			if (node.getFCost() < minCost) {
				min = node;
				minCost = node.getFCost();
			}
		return min;
	}

	private int getDistance(Point a, Point b) {
		return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
	}

	private Direction getDirection(Point a, Point b) {
		if (a.x + 1 == b.x && a.y == b.y)
			return Direction.RIGHT;
		if (a.x - 1 == b.x && a.y == b.y)
			return Direction.LEFT;
		if (a.x == b.x && a.y + 1 == b.y)
			return Direction.DOWN;
		if (a.x == b.x && a.y - 1 == b.y)
			return Direction.UP;
		return null;
	}
	//Calculate Valid Moves
	public static boolean isMoveValid(Direction d, Snake snake, GameInfo gameInfo) {
		Point newHead = new Point(snake.headPosition().x, snake.headPosition().y);
		switch(d) {
		case DOWN:
			newHead.y++;
			break;
		case LEFT:
			newHead.x--;
			break;
		case RIGHT:
			newHead.x++;
			break;
		case UP:
			newHead.y--;
			break;
		default:
			break;
		}
		if (newHead.x == -1) {
			newHead.x = gameInfo.field().width()-1;
		}
		if (newHead.x == gameInfo.field().width()) {
			newHead.x = 0;
		}
		if (newHead.y == -1) {
			newHead.y = gameInfo.field().height()-1;
		}
		if (newHead.y == gameInfo.field().height()) {
			newHead.y = 0;
		}
		
		return gameInfo.field().cell(newHead) == CellType.SPACE || gameInfo.field().cell(newHead) == CellType.APPLE;
	}
	public static boolean isValidMovePossible(Snake snake, GameInfo gameInfo) {
		return isMoveValid(Direction.DOWN, snake, gameInfo) || isMoveValid(Direction.UP, snake, gameInfo) || isMoveValid(Direction.LEFT, snake, gameInfo) || isMoveValid(Direction.RIGHT, snake, gameInfo);
	}
}