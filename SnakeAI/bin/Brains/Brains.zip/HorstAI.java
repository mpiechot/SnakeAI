package Brains;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import Logic.Field;
import Logic.Field.CellType;
import Logic.GameInfo;
import Logic.Point;
import Logic.Snake;
import Logic.Snake.Direction;
import Logic.SnakeBrain;

//HorstAI
//Created by: Julia Hofmann, Marco Piechotta

public class HorstAI implements SnakeBrain {
	private HashMap<Point, Integer> apples = new HashMap<>();
	private Node start;
	private Node target;
	
	//A* 
	private int[][] moveableMap;
	private int[][] heuristik;
	private List<Node> openList = new LinkedList<>();
	private List<Node> closedList = new LinkedList<>();

	@Override
	public Direction nextDirection(GameInfo gameInfo, Snake snake) {
		Direction move = null;
		start = new Node(snake.headPosition(),snake.headPosition(),0,0);
		getApples(gameInfo.field(), start.getFrom());
		do {
			//bestimme den naechsten Apfel 
			int minDist = Integer.MAX_VALUE;
			Point minPoint = null;
			for (Entry<Point, Integer> apple : apples.entrySet()) {
				if (apple.getValue() < minDist) {
					minPoint = apple.getKey();
					minDist = apple.getValue();
				}
			}
			target = new Node(minPoint,minPoint,0,0);
			apples.remove(minPoint);
			System.out.println("target: " + target);
			
			//Ist das Ziel direkt erreichbar, laufe dort hin!
			if (Math.abs(minPoint.x - start.getTo().x) == 1 && minPoint.y == start.getTo().y)
				return getDirection(start.getTo(), target.getTo());
			if (Math.abs(minPoint.y - start.getTo().y) == 1 && minPoint.x == start.getTo().x)
				return getDirection(start.getTo(), target.getTo());
			
			calculateMoveMap(gameInfo.field());
			//Ist das Ziel nicht durch 1 Schritt erreichbar, suche den Weg dort hin
			move = getPath();
		} while (move == null);
		return move;
	}

	private void getApples(Field f, Point snakeHead) {
		apples.clear();
		for (int i = 0; i < f.width(); i++)
			for (int j = 0; j < f.height(); j++)
				if (f.getApple(new Point(i, j)) != null) {
					int dist = Math.abs(snakeHead.x - i + snakeHead.y - j);
					apples.put(new Point(i, j), dist);
				}
	}

	private void calculateMoveMap(Field f) {
		moveableMap = new int[f.width() + 1][f.height() + 1];
		heuristik = new int[f.width() + 1][f.height() + 1];
		for (int i = 0; i < f.width(); i++) {
			for (int j = 0; j < f.height(); j++) {
				heuristik[i][j] = getDistance(new Point(i,j),target.getTo());
				if (f.cell(new Point(i, j)).equals(CellType.APPLE))
					moveableMap[i][j] = 1;
				if (f.cell(new Point(i, j)).equals(CellType.WALL))
					moveableMap[i][j] = 99;
				if (f.cell(new Point(i, j)).equals(CellType.SPACE))
					moveableMap[i][j] = 1;
				if (f.cell(new Point(i, j)).equals(CellType.SNAKE)) {
					moveableMap[i][j] = 99;
				}
			}
		}
	}

	private Direction getPath() {
		openList.clear();
		closedList.clear();
		
		// Calculate A*
		openList.add(start);
		while (!isInClosedList(target) && !openList.isEmpty()) {
			Node min = getMin();
			openList.remove(min);
			closedList.add(min);
			Point current = min.getTo();
			for (int i = -1; i <= 1; i += 2) {
				if (current.x + i < 30 && current.x + i >= 0)
					updateOpenList(new Point(current.x + i, current.y), min);
				if (current.y + i < 20 && current.y + i >= 0)
					updateOpenList(new Point(current.x, current.y + i), min);
			}
		}
		Node field = getMovePair(target.getTo());
		if (field == null) {
			return null;
		}
		closedList.remove(0);
		while (!field.getFrom().equals(start.getFrom())) {
			field = getMovePair(field.getFrom());
		}
		return getDirection(field.getFrom(), field.getTo());
	}

	private void updateOpenList(Point check, Node node) {
		Node checkNode = new Node(node,check,heuristik[check.x][check.y],moveableMap[check.x][check.y]);
		if (!isInClosedList(checkNode))
			if (isInOpenList(checkNode)) {
				Node duplicate = getElement(checkNode);
				if (checkNode.getGCosts() < duplicate.getGCosts()) {
					openList.remove(duplicate);
					openList.add(checkNode);
				}
			} else
				openList.add(checkNode);
	}
	private boolean isInClosedList(Node n) {
		for (Node closed : closedList)
		{
			if (closed.getTo().equals(n.getTo()))
				return true;
		}
		return false;
	}

	private Node getMovePair(Point p) {
		for (Node n : closedList)
			if (n.getTo().equals(p))
				return n;

		return null;
	}

	private boolean isInOpenList(Node n) {
		for (Node open : openList)
		{
			if (open.getTo().equals(n.getTo()))
				return true;
		}
		return false;
	}

	private Node getElement(Node n) {
		for (Node open : openList)
		{
			if (open.getTo().equals(n.getTo()))
				return open;
		}
		return null;
	}

	private Node getMin() {
		int minCost = Integer.MAX_VALUE;
		Node min = null;
		for (Node node : openList)
			if (node.getFCost() < minCost) {
				min = node;
				minCost = node.getFCost();
			}
		return min;
	}

	private int getDistance(Point a, Point b) {
		return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
	}

	private Direction getDirection(Point a, Point b) {
		if (a.x + 1 == b.x && a.y == b.y)
			return Direction.RIGHT;
		if (a.x - 1 == b.x && a.y == b.y)
			return Direction.LEFT;
		if (a.x == b.x && a.y + 1 == b.y)
			return Direction.DOWN;
		if (a.x == b.x && a.y - 1 == b.y)
			return Direction.UP;
		return null;
	}
	//Calculate Valid Moves
	public static boolean isMoveValid(Direction d, Snake snake, GameInfo gameInfo) {
		Point newHead = new Point(snake.headPosition().x, snake.headPosition().y);
		switch(d) {
		case DOWN:
			newHead.y++;
			break;
		case LEFT:
			newHead.x--;
			break;
		case RIGHT:
			newHead.x++;
			break;
		case UP:
			newHead.y--;
			break;
		default:
			break;
		}
		if (newHead.x == -1) {
			newHead.x = gameInfo.field().width()-1;
		}
		if (newHead.x == gameInfo.field().width()) {
			newHead.x = 0;
		}
		if (newHead.y == -1) {
			newHead.y = gameInfo.field().height()-1;
		}
		if (newHead.y == gameInfo.field().height()) {
			newHead.y = 0;
		}
		
		return gameInfo.field().cell(newHead) == CellType.SPACE || gameInfo.field().cell(newHead) == CellType.APPLE;
	}
	
	public static boolean isValidMovePossible(Snake snake, GameInfo gameInfo) {
		return isMoveValid(Direction.DOWN, snake, gameInfo) || isMoveValid(Direction.UP, snake, gameInfo) || isMoveValid(Direction.LEFT, snake, gameInfo) || isMoveValid(Direction.RIGHT, snake, gameInfo);
	}
}
class Node{
	private Point from;
	private Point to;
	private int gCosts;
	private int hCosts;
	
	public Node (Node from, Point to, int heuristik, int moveCost)
	{
		this.from = from.getTo();
		this.to = to;
		hCosts = heuristik;
		gCosts = from.getGCosts() + moveCost;
	}
	public Node (Point from, Point to, int heuristik, int moveCost)
	{
		this.from = from;
		this.to = to;
		hCosts = heuristik;
		gCosts = moveCost;
	}
	public int getFCost()
	{
		return gCosts + hCosts;
	}
	public int getGCosts()
	{
		return gCosts;
	}
	public int getHCosts()
	{
		return hCosts;
	}
	public Point getFrom()
	{
		return from;
	}
	public Point getTo()
	{
		return to;
	}
	public void updateNode(Point from, int newGCost)
	{
		this.from = from;
		gCosts = newGCost;
	}
	@Override
	public String toString()
	{
		return "[("+from.x +":"+from.y+") -> ("+to.x+":"+to.y+"): G: " +gCosts+" F: " + getFCost()+"]";
	}
}
